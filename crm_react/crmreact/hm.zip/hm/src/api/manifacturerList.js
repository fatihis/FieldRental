export const vehicleBrands = [
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/alfa_romeo.png",
    name: "Alfa Romeo",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/audi.png",
    name: "Audi",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/bmw.png",
    name: "BMW",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/chevrolet.png",
    name: "Chevrolet",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/citroen.png",
    name: "Citroën",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/dacia.png",
    name: "Dacia",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/daf.png",
    name: "Daf",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/daihat.png",
    name: "Daihatsu",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/fiat.png",
    name: "Fiat",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/ford.png",
    name: "Ford",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/geely.png",
    name: "Geely",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/gm.png",
    name: "General Motors",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/gmc.png",
    name: "GMC",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/honda.png",
    name: "Honda",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/hyundai.png",
    name: "Hyundai",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/inf.png",
    name: "Infiniti",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/isuzu.png",
    name: "Isuzu",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/jeep.png",
    name: "Jeep",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/kia.png",
    name: "Kia",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/lada.png",
    name: "Lada",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/lancia.png",
    name: "Lancia",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/land-rover.png",
    name: "Land Rover",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/lexus.png",
    name: "Lexus",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/mazda.png",
    name: "Mazda",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/marchedrs.png",
    name: "Mercedes",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/mitub.png",
    name: "Mitsubishi",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/nissan.png",
    name: "Nissan",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/opel.png",
    name: "Opel",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/peug.png",
    name: "Peugeot",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/porsche.png",
    name: "Porsche",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/renault.png",
    name: "Renault",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/saab.png",
    name: "Saab",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/scania.png",
    name: "Scania",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/seat.png",
    name: "Seat",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/skoda.png",
    name: "Skoda",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/smart.png",
    name: "Smart",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/ssangyong.png",
    name: "Ssangyong",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/subaru.png",
    name: "Subaru",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/suzuki.png",
    name: "Suzuki",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/tata.png",
    name: "Tata",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/tesla.png",
    name: "Tesla",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/toyota.png",
    name: "Toyota",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/volkswagen.png",
    name: "Volkswagen",
  },
  {
    logo: "https://www.car-logos.org/wp-content/uploads/2011/09/volvo.png",
    name: "Volvo",
  },
];
